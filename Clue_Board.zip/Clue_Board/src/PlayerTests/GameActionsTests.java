package PlayerTests;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import clueGame.*;

public class GameActionsTests {
	//declarations/variables
	public static Board board;
	
	@BeforeClass
	public static void setUp() {
		//stub
	}
	
	@Test
	public void accusationTest() {
		//stub
	}
	
	@Test
	public void selectLocationTest() {
		//stub
	}
	
	@Test
	public void disproveSuggestionTest() {
		//stub
	}
	
	@Test
	public void makeSuggestionTest() {
		//stub
	}

}
