package clueGame;

import java.util.ArrayList;

public class Player {
	private String name;
	private String color;
	private int startingLocation;
	private ArrayList<Card> hand;
	
	public void disproveSuggestion(String person, String room, String weapon) {
		
	}
	
	
	
	
	
	
	
	//for testing
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getStartingLocation() {
		return startingLocation;
	}

	public void setStartingLocation(int startingLocation) {
		this.startingLocation = startingLocation;
	}

	public ArrayList<Card> getHand() {
		return hand;
	}

	public void setHand(ArrayList<Card> hand) {
		this.hand = hand;
	}
	
}
