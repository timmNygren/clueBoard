package clueGame;

import java.util.ArrayList;

public class ComputerPlayer extends Player {
	private ArrayList<Integer/*targets*/> locations;
	private char lastRoomVisited;
	
	public ComputerPlayer() {
		super();
	}
	
	public void pickLocation(/*needs targets*/) {
		//stub
	}
	
	public void createSuggestion() {
		//stub
	}
	
	public void updateSeen(Card seen) {
		//stub
	}
}
